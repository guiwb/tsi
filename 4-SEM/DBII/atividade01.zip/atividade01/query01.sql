select nome from funcionarios

union

select nome from clientes