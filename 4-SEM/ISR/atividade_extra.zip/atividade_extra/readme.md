### Link do Projeto
http://atividade-tsi-guilherme.free.nf/?i=1

### Plataforma utilizada
InfinityFree

### Descrição do projeto
Sistema de cadastrar usuários. O sistema cadastra apenas um usuário por e-mail.

### Dificuldades encontradas
Nenhuma.